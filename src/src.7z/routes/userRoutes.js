import express from "express";
import {
  registerUser,
  loginUser,
  logoutDevice,
  logoutAll,
  getProfile,
  updateProfile,
  changePassword,
  forgotPassword,
  resetPassword,
  addToWatchlist,
  removeFromWatchlist,
  getWatchlist,
  deleteAccount,
  getUserDashboard,
  getContinueWatching,
} from "../controllers/userController.js";

import { isAuthenticated } from "../middlewares/auth.js";

const router = express.Router();

// 🔹 Auth
router.post("/register", registerUser);
router.post("/login", loginUser);
router.post("/logout-device", isAuthenticated, logoutDevice);
router.post("/logout-all", isAuthenticated, logoutAll);

// 🔹 Profile
router.get("/me", isAuthenticated, getProfile);
router.put("/me", isAuthenticated, updateProfile);
router.delete("/me", isAuthenticated, deleteAccount);

// 🔹 Password
router.put("/change-password", isAuthenticated, changePassword);
router.post("/forgot-password", forgotPassword);
router.put("/reset-password/:token", resetPassword);

// 🔹 Watchlist
router.post("/watchlist/add", isAuthenticated, addToWatchlist);
router.post("/watchlist/remove", isAuthenticated, removeFromWatchlist);
router.get("/watchlist", isAuthenticated, getWatchlist);
import { getUserDashboard } from "../controllers/userController.js";

router.get("/dashboard", isAuthenticated, getUserDashboard);
router.get("/continue-watching", isAuthenticated, getContinueWatching);

export default router;

import { User } from "../models/User.js";
import { Device } from "../models/Device.js";
import { WatchHistory } from "../models/WatchHistory.js";
import { Rating } from "../models/Rating.js";
import { Notification } from "../models/Notification.js";
import { AuditLog } from "../models/AuditLog.js";
import { Subscription } from "../models/Subscription.js";
import { Content } from "../models/Content.js";
import ErrorHandle from "../utils/errorHandle.js";
import { catchAsyncError } from "../utils/catchAsyncError.js";
import { sendToken } from "../utils/sendToken.js";
import crypto from "crypto";

//
// 🔹 Register
//
export const registerUser = catchAsyncError(async (req, res, next) => {
  const { firstName, lastName, email, contact, password } = req.body;

  if (!email || !contact || !password) {
    return next(new ErrorHandle("Please provide all required fields", 400));
  }

  const existing = await User.findOne({ email });
  if (existing) return next(new ErrorHandle("User already exists", 400));

  const user = await User.create({
    firstName,
    lastName,
    email,
    contact,
    password,
  });

  await AuditLog.create({
    userId: user._id,
    action: "register",
    ipAddress: req.ip,
    userAgent: req.headers["user-agent"],
  });

  sendToken(res, user, 201, "Registered successfully");
});

//
// 🔹 Login
//
export const loginUser = catchAsyncError(async (req, res, next) => {
  const { email, password, deviceId, deviceType } = req.body;

  const user = await User.findOne({ email }).select("+password");
  if (!user) return next(new ErrorHandle("Invalid email or password", 401));

  if (user.isAccountLocked()) {
    return next(new ErrorHandle("Account locked. Try again later.", 403));
  }

  const isMatch = await user.comparePassword(password);
  if (!isMatch) {
    await user.incrementLoginAttempts();
    return next(new ErrorHandle("Invalid email or password", 401));
  }

  const token = user.getJWTToken();

  // Attach device entry
  let device = await Device.findOne({ deviceId, userId: user._id });

  if (!device) {
    const count = await Device.countDocuments({ userId: user._id });
    if (count >= 5)
      return next(new ErrorHandle("Maximum device limit reached", 403));

    device = await Device.create({
      userId: user._id,
      deviceId: deviceId || crypto.randomUUID(),
      deviceType: deviceType || "web",
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"],
      activeToken: token,
    });

    user.devices.push(device._id);
  } else {
    device.activeToken = token;
    device.lastActiveAt = new Date();
    await device.save();
  }

  user.failedLoginAttempts = 0;
  user.lockUntil = undefined;
  user.lastLoginAt = new Date();
  user.lastLoginIP = req.ip;
  user.lastLoginDevice = device.deviceType;
  await user.save();

  await AuditLog.create({
    userId: user._id,
    action: "login",
    ipAddress: req.ip,
    userAgent: req.headers["user-agent"],
  });

  sendToken(res, user, 200, "Logged in successfully");
});

//
// 🔹 Logout one device
//
export const logoutDevice = catchAsyncError(async (req, res, next) => {
  const { deviceId } = req.body;
  await Device.deleteOne({ userId: req.user._id, deviceId });

  await User.findByIdAndUpdate(req.user._id, { $pull: { devices: deviceId } });

  await AuditLog.create({
    userId: req.user._id,
    action: "logout",
    ipAddress: req.ip,
    userAgent: req.headers["user-agent"],
  });

  res.status(200).json({ success: true, message: "Logged out from device" });
});

//
// 🔹 Logout all devices
//
export const logoutAll = catchAsyncError(async (req, res, next) => {
  await Device.deleteMany({ userId: req.user._id });

  await User.findByIdAndUpdate(req.user._id, { devices: [] });

  await AuditLog.create({
    userId: req.user._id,
    action: "logout_all",
    ipAddress: req.ip,
    userAgent: req.headers["user-agent"],
  });

  res
    .status(200)
    .json({ success: true, message: "Logged out from all devices" });
});

//
// 🔹 Profile
//
export const getProfile = catchAsyncError(async (req, res, next) => {
  const user = await User.findById(req.user._id)
    .populate("subscriptionId")
    .populate("devices")
    .populate("watchlist", "title thumbnail")
    .populate("ratings")
    .populate("notifications")
    .populate("auditLogs");

  if (!user) return next(new ErrorHandle("User not found", 404));

  res.status(200).json({ success: true, user });
});

export const updateProfile = catchAsyncError(async (req, res, next) => {
  const updates = req.body;
  const user = await User.findByIdAndUpdate(req.user._id, updates, {
    new: true,
    runValidators: true,
  });

  await AuditLog.create({
    userId: req.user._id,
    action: "profile_update",
    ipAddress: req.ip,
    userAgent: req.headers["user-agent"],
  });

  res.status(200).json({ success: true, user });
});

//
// 🔹 Password
//
export const changePassword = catchAsyncError(async (req, res, next) => {
  const { oldPassword, newPassword } = req.body;

  const user = await User.findById(req.user._id).select("+password");
  if (!user) return next(new ErrorHandle("User not found", 404));

  const isMatch = await user.comparePassword(oldPassword);
  if (!isMatch) return next(new ErrorHandle("Incorrect current password", 401));

  user.password = newPassword;
  await user.save();

  await AuditLog.create({
    userId: req.user._id,
    action: "password_change",
    ipAddress: req.ip,
    userAgent: req.headers["user-agent"],
  });

  res.status(200).json({ success: true, message: "Password updated" });
});

export const forgotPassword = catchAsyncError(async (req, res, next) => {
  const { email } = req.body;
  const user = await User.findOne({ email });
  if (!user) return next(new ErrorHandle("No user found with this email", 404));

  const resetToken = user.getResetToken();
  await user.save({ validateBeforeSave: false });

  // TODO: integrate email service
  res.status(200).json({ success: true, resetToken });
});

export const resetPassword = catchAsyncError(async (req, res, next) => {
  const resetPasswordToken = crypto
    .createHash("sha256")
    .update(req.params.token)
    .digest("hex");

  const user = await User.findOne({
    resetPasswordToken,
    resetPasswordTokenExpire: { $gt: Date.now() },
  });

  if (!user) return next(new ErrorHandle("Invalid or expired token", 400));

  user.password = req.body.password;
  user.resetPasswordToken = undefined;
  user.resetPasswordTokenExpire = undefined;
  await user.save();

  await AuditLog.create({
    userId: user._id,
    action: "password_reset",
    ipAddress: req.ip,
    userAgent: req.headers["user-agent"],
  });

  res.status(200).json({ success: true, message: "Password reset successful" });
});

//
// 🔹 Watchlist
//
export const addToWatchlist = catchAsyncError(async (req, res, next) => {
  const { contentId } = req.body;
  const user = await User.findById(req.user._id);

  if (!user.watchlist.includes(contentId)) {
    user.watchlist.push(contentId);
    await user.save();
  }

  res.status(200).json({ success: true, watchlist: user.watchlist });
});

export const removeFromWatchlist = catchAsyncError(async (req, res, next) => {
  const { contentId } = req.body;
  const user = await User.findById(req.user._id);

  user.watchlist = user.watchlist.filter(
    (id) => String(id) !== String(contentId)
  );
  await user.save();

  res.status(200).json({ success: true, watchlist: user.watchlist });
});

export const getWatchlist = catchAsyncError(async (req, res, next) => {
  const user = await User.findById(req.user._id).populate(
    "watchlist",
    "title thumbnail"
  );
  res.status(200).json({ success: true, watchlist: user.watchlist });
});

//
// 🔹 Delete Account
//
export const deleteAccount = catchAsyncError(async (req, res, next) => {
  const user = await User.findById(req.user._id);
  if (!user) return next(new ErrorHandle("User not found", 404));

  await Device.deleteMany({ userId: user._id });
  await WatchHistory.deleteMany({ userId: user._id });
  await Rating.deleteMany({ userId: user._id });
  await Notification.deleteMany({ userId: user._id });
  await AuditLog.deleteMany({ userId: user._id });
  await Subscription.deleteMany({ userId: user._id });

  await user.deleteOne();

  res.status(200).json({ success: true, message: "Account deleted" });
});

export const getUserDashboard = catchAsyncError(async (req, res, next) => {
  const userId = req.user._id;

  const result = await User.aggregate([
    { $match: { _id: new mongoose.Types.ObjectId(userId) } },

    // 🔹 Subscription
    {
      $lookup: {
        from: "subscriptions",
        localField: "subscriptionId",
        foreignField: "_id",
        as: "subscription",
      },
    },
    { $unwind: { path: "$subscription", preserveNullAndEmptyArrays: true } },

    // 🔹 Watchlist with content details
    {
      $lookup: {
        from: "contents",
        localField: "watchlist",
        foreignField: "_id",
        as: "watchlistDetails",
        pipeline: [
          { $project: { title: 1, thumbnail: 1, type: 1, isTrending: 1 } },
        ],
      },
    },

    // 🔹 Recent WatchHistory with content details
    {
      $lookup: {
        from: "watchhistories",
        localField: "_id",
        foreignField: "userId",
        as: "watchHistoryDetails",
        pipeline: [
          { $sort: { lastWatchedAt: -1 } },
          { $limit: 10 }, // last 10
          {
            $lookup: {
              from: "contents",
              localField: "contentId",
              foreignField: "_id",
              as: "contentDetails",
              pipeline: [{ $project: { title: 1, thumbnail: 1, duration: 1 } }],
            },
          },
          { $unwind: "$contentDetails" },
        ],
      },
    },

    // 🔹 Notifications
    {
      $lookup: {
        from: "notifications",
        localField: "_id",
        foreignField: "userId",
        as: "notifications",
        pipeline: [
          { $sort: { sentAt: -1 } },
          { $limit: 5 }, // last 5
          { $project: { title: 1, message: 1, isRead: 1, sentAt: 1 } },
        ],
      },
    },

    // 🔹 Final projection
    {
      $project: {
        firstName: 1,
        lastName: 1,
        email: 1,
        role: 1,
        profilePicture: 1,
        accountStatus: 1,
        subscription: 1,
        watchlistDetails: 1,
        watchHistoryDetails: 1,
        notifications: 1,
      },
    },
  ]);

  if (!result || result.length === 0) {
    return next(new ErrorHandle("User not found", 404));
  }

  res.status(200).json({ success: true, dashboard: result[0] });
});

export const getContinueWatching = catchAsyncError(async (req, res, next) => {
  const userId = req.user._id;

  const history = await WatchHistory.aggregate([
    {
      $match: { userId: new mongoose.Types.ObjectId(userId), completed: false },
    },
    { $sort: { lastWatchedAt: -1 } },
    { $limit: 15 }, // Limit results for UI row

    {
      $lookup: {
        from: "contents",
        localField: "contentId",
        foreignField: "_id",
        as: "contentDetails",
        pipeline: [
          {
            $project: {
              title: 1,
              thumbnail: 1,
              duration: 1,
              type: 1,
              genres: 1,
            },
          },
        ],
      },
    },
    { $unwind: "$contentDetails" },

    {
      $addFields: {
        progressPercent: {
          $multiply: [
            { $divide: ["$progress", "$contentDetails.duration"] },
            100,
          ],
        },
      },
    },
  ]);

  res.status(200).json({
    success: true,
    results: history.map((h) => ({
      contentId: h.contentId,
      title: h.contentDetails.title,
      thumbnail: h.contentDetails.thumbnail,
      type: h.contentDetails.type,
      genres: h.contentDetails.genres,
      progress: h.progress,
      duration: h.contentDetails.duration,
      progressPercent: Math.min(100, Math.round(h.progressPercent)),
      lastWatchedAt: h.lastWatchedAt,
    })),
  });
});
